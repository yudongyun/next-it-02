package dongyun.submit09;

public class CafeMain {

	public static void main(String[] args) {

	}

}
